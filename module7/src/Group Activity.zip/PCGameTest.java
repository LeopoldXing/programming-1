public class PCGameTest {
    public static void main(String[] args) {
        Borderlands borderlands = new Borderlands();

        System.out.println(borderlands);
    }
}
