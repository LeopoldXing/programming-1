public enum BorderlandsDifficultyMode {
    EASY,
    MEDIUM,
    HARD,
    VERY_HARD;

    private BorderlandsDifficultyMode() {
    }
}
