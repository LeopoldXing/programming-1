public enum BorderlandsCharacter {
    BRICK,
    LILITH,
    MORDECAI,
    ROLAND;

    private BorderlandsCharacter() {
    }
}
